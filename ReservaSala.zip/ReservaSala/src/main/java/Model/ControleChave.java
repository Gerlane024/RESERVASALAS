/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author devmat
 */
import java.util.Date;

public class ControleChave {

    private int idControle;
    private int idSala;
    private int idFuncionario;
    private Integer idProfessor; // Pode ser nulo
    private Date dataEntrega;
    private String horaEntrega;
    private Date dataDevolucao;
    private String horaDevolucao;

    // Construtores, getters e setters

    public ControleChave(int idControle, int idSala, int idFuncionario, Integer idProfessor, Date dataEntrega, String horaEntrega, Date dataDevolucao, String horaDevolucao) {
        this.idControle = idControle;
        this.idSala = idSala;
        this.idFuncionario = idFuncionario;
        this.idProfessor = idProfessor;
        this.dataEntrega = dataEntrega;
        this.horaEntrega = horaEntrega;
        this.dataDevolucao = dataDevolucao;
        this.horaDevolucao = horaDevolucao;
    }

    public int getIdControle() {
        return idControle;
    }

    public void setIdControle(int idControle) {
        this.idControle = idControle;
    }

    public int getIdSala() {
        return idSala;
    }

    public void setIdSala(int idSala) {
        this.idSala = idSala;
    }

    public int getIdFuncionario() {
        return idFuncionario;
    }

    public void setIdFuncionario(int idFuncionario) {
        this.idFuncionario = idFuncionario;
    }

    public Integer getIdProfessor() {
        return idProfessor;
    }

    public void setIdProfessor(Integer idProfessor) {
        this.idProfessor = idProfessor;
    }

    public Date getDataEntrega() {
        return dataEntrega;
    }

    public void setDataEntrega(Date dataEntrega) {
        this.dataEntrega = dataEntrega;
    }

    public String getHoraEntrega() {
        return horaEntrega;
    }

    public void setHoraEntrega(String horaEntrega) {
        this.horaEntrega = horaEntrega;
    }

    public Date getDataDevolucao() {
        return dataDevolucao;
    }

    public void setDataDevolucao(Date dataDevolucao) {
        this.dataDevolucao = dataDevolucao;
    }

    public String getHoraDevolucao() {
        return horaDevolucao;
    }

    public void setHoraDevolucao(String horaDevolucao) {
        this.horaDevolucao = horaDevolucao;
    }
}

