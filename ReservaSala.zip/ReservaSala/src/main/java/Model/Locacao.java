/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author devmat*/

import java.util.Date;

public class Locacao {

    private int idAlocacao;
    private int idProfessor;
    private int idSala;
    private int idTurno;
    private Date dataAlocacao;

    // Construtores, getters e setters

    public Locacao(int idAlocacao, int idProfessor, int idSala, int idTurno, Date dataAlocacao) {
        this.idAlocacao = idAlocacao;
        this.idProfessor = idProfessor;
        this.idSala = idSala;
        this.idTurno = idTurno;
        this.dataAlocacao = dataAlocacao;
    }

    public int getIdAlocacao() {
        return idAlocacao;
    }

    public void setIdAlocacao(int idAlocacao) {
        this.idAlocacao = idAlocacao;
    }

    public int getIdProfessor() {
        return idProfessor;
    }

    public void setIdProfessor(int idProfessor) {
        this.idProfessor = idProfessor;
    }

    public int getIdSala() {
        return idSala;
    }

    public void setIdSala(int idSala) {
        this.idSala = idSala;
    }

    public int getIdTurno() {
        return idTurno;
    }

    public void setIdTurno(int idTurno) {
        this.idTurno = idTurno;
    }

    public Date getDataAlocacao() {
        return dataAlocacao;
    }

    public void setDataAlocacao(Date dataAlocacao) {
        this.dataAlocacao = dataAlocacao;
    }
}
