/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author devmat
 */
import java.time.LocalTime;

public class Turno {

    private int idTurno;
    private String periodo;
    private LocalTime horarioInicio;
    private LocalTime horarioFim;

    // Construtores, getters e setters

    public Turno(int idTurno, String periodo, LocalTime horarioInicio, LocalTime horarioFim) {
        this.idTurno = idTurno;
        this.periodo = periodo;
        this.horarioInicio = horarioInicio;
        this.horarioFim = horarioFim;
    }

    public int getIdTurno() {
        return idTurno;
    }

    public void setIdTurno(int idTurno) {
        this.idTurno = idTurno;
    }

    public String getPeriodo() {
        return periodo;
    }

    public void setPeriodo(String periodo) {
        this.periodo = periodo;
    }

    public LocalTime getHorarioInicio() {
        return horarioInicio;
    }

    public void setHorarioInicio(LocalTime horarioInicio) {
        this.horarioInicio = horarioInicio;
    }

    public LocalTime getHorarioFim() {
        return horarioFim;
    }

    public void setHorarioFim(LocalTime horarioFim) {
        this.horarioFim = horarioFim;
    }
}
