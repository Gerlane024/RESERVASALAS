package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

// @author jhessikkaelly

public class ConexaoBancoDeDados {
    // conectando com SQL Server
    /* CRIANDO UMA VARIÁVEL PARA CAPTURAR O ENDEREÇO DE CONEXÃO
    COM O BANCO DE DADOS.
    JDBC:SQLSERVER - É O DRIVER
    LOCALHOST - SERVIDOR   1433 - PORTA UTILIZADA
    DATABASENAME=  NOME DO SEU BANCO DE DADOS
    INTEGRATEDSECURITY E TRUSTSERVERCERTIFICATE SÃO PARA LOGAR*/
   
    // Modifiquei o nome do banco para 'ReservaSalas'
    private static final String URL =
           "jdbc:sqlserver://localhost:1433;databaseName=ReservaSalas;"
           + "integratedSecurity=true;"
           + "trustServerCertificate=true";
   
   // Método para obter a conexão
   public static Connection getConnection(){
       // Criando um objeto do tipo Connection
       Connection conection = null;
       try {
           // Estabelece a conexão com o banco de dados
           conection = DriverManager.getConnection(URL);
           System.out.println("Conexão bem sucedida!");
       } catch (SQLException e) { 
           // Caso ocorra algum erro, exibe a mensagem de erro
           System.out.println("Erro de Conexão: " + e);
       }
       return conection;
   }
}
